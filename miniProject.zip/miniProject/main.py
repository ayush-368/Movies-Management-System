import streamlit as st
import pandas as pd
import mysql.connector
from PIL import Image
import base64


def set_bg_hack(main_bg):

    main_bg_ext = "png"

    st.markdown(
        f"""
         <style>
         .stApp {{
             background: url(data:image/{main_bg_ext};base64,{base64.b64encode(open(main_bg, "rb").read()).decode()});
             background-size: cover
         }}
         </style>
         """,
        unsafe_allow_html=True
    )
set_bg_hack('theator.jpg')



def sidebar_bg(side_bg):

   side_bg_ext = 'gif'

   st.markdown(
      f"""
      <style>
      [data-testid="stSidebar"] > div:first-child {{
          background: url(data:image/{side_bg_ext};base64,{base64.b64encode(open(side_bg, "rb").read()).decode()});
      }}
      </style>
      """,
      unsafe_allow_html=True,
      )

try:
    conn = mysql.connector.connect(host='localhost' , username='root' ,password='Ayush@#121' , database='mini_projects')
    curr = conn.cursor()

    side_bg = 'theator.jpg'
    sidebar_bg(side_bg)

    st.title('Movies Management System')

    c1,c2,c3 = st.columns(3)
    c4,c5,c6 = st.columns(3)
    c7,c8,c9 = st.columns(3)

    image=Image.open("theator.jpg")
    st.sidebar.image(image)

    choice = st.sidebar.selectbox("Select a choice: ",('Insert','Update','Delete','Search','Display'))

    def insert(id, name, date, director, cast, budget, duration, rating):
        insert_query = "insert into movies values (%s,%s,%s,%s,%s,%s,%s,%s)"
        val = (id, name, date, director, cast, budget, duration, rating)
        curr.execute(insert_query, val)
        conn.commit()

    def del_by_id(in_id):
        delete_query = 'delete from movies where id= %s'
        val = [in_id]
        curr.execute(delete_query, val)
        conn.commit()
    def del_by_name(in_name):
        delete_query = 'delete from movies where movie_name = %s'
        val = [in_name]
        curr.execute(delete_query, val)
        conn.commit()

    def update_name_by_id(new_movie,id):
        val = (new_movie, id)
        update_query = "update movies set movie_name=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_date_by_id(new_date,id):
        val = (new_date, id)
        update_query = "update movies set release_date=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_director_by_id(new_director,id):
        val = (new_director, id)
        update_query = "update movies set director=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_cast_by_id(new_cast,id):
        val = (new_cast, id)
        update_query = "update movies set cast=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_budget_by_id(new_budget,id):
        val = (new_budget, id)
        update_query = "update movies set budget=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_duration_by_id(new_duration,id):
        val = (new_duration, id)
        update_query = "update movies set duration=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_rating_by_id(new_rating,id):
        val = (new_rating, id)
        update_query = "update movies set rating=%s where id=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_id_by_name(new_id,name):
        val = (new_id, name)
        update_query = "update movies set id=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_date_by_name(new_date,name):
        val = (new_date, name)
        update_query = "update movies set release_date=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_director_by_name(new_director,name):
        val = (new_director, name)
        update_query = "update movies set director=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_cast_by_name(new_cast,name):
        val = (new_cast, name)
        update_query = "update movies set cast=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_budget_by_name(new_budget,name):
        val = (new_budget, name)
        update_query = "update movies set budget=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_duration_by_name(new_duration,name):
        val = (new_duration, name)
        update_query = "update movies set duration=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()
    def update_rating_by_name(new_rating,name):
        val = (new_rating, name)
        update_query = "update movies set rating=%s where movie_name=%s"
        curr.execute(update_query, val)
        conn.commit()

    def search_by_id():
        in_id = st.number_input('Id')
        val = [in_id]
        select_query = "select * from movies where id=%s"
        curr.execute(select_query, val)
    def search_by_name():
        name = st.text_input('Name')
        val = [name]
        select_query = "select * from movies where movie_name=%s"
        curr.execute(select_query, val)



    if (choice == 'Insert'):
    # if(choice1):
        with c1:
            id = st.number_input("Movie Id")
        with c2:
            name = st.text_input("Movie Name")
        with c3:
            date = st.date_input("Date")
        with c4:
            director = st.text_input("Director")
        with c5:
            cast = st.text_input("Cast")
        with c6:
            budget = st.number_input("Budget (in Crores)")
        with c7:
            duration = st.number_input("Duration (in hrs)")
        with c8:
            rating = st.number_input("Rating (Out of 5)")
        try:
            if st.button('Insert'):
                insert(id, name, date, director, cast, budget, duration, rating);
        except Exception as e:
            st.write('Found an exception')
            st.write('Please Enter valid data')


    if (choice == 'Delete'):
    # if (choice4):
        ch = st.selectbox('Select',('By Id','By Name'))

        if(ch == 'By Id'):
            in_id = st.number_input('Id to delete record')
            if(st.button('Delete')):
                del_by_id(in_id)

        if(ch == 'By Name'):
            in_name = st.text_input('Name to delete record')
            if(st.button('Delete')):
                del_by_name(in_name)

    if(choice == 'Update'):
    # if (choice2):
        ch = st.selectbox('Select',('By Id','By Name'))



        if(ch=='By Id'):
            id = st.text_input('Id')

            c1, c2, c3 = st.columns(3)
            c4, c5, c6 = st.columns(3)
            c7, c8, c9 = st.columns(3)

            with c1:
                name = st.checkbox('Movie Name')
            with c2:
                date = st.checkbox('Date')
            with c3:
                director = st.checkbox('Director')
            with c4:
                cast = st.checkbox('Cast')
            with c5:
                budget = st.checkbox('Budget')
            with c6:
                duration = st.checkbox('Duration')
            with c7:
                rating = st.checkbox('Rating')


            if name:
                new_movie = st.text_input("Movie Name")
            if date:
                new_date = st.date_input("Date")
            if director:
                new_director = st.text_input("Director")
            if cast:
                new_cast = st.text_input("Cast")
            if budget:
                new_budget = st.number_input("Budget")
            if duration:
                new_duration = st.number_input("Duration")
            if rating:
                new_rating = st.number_input("Rating")


            if (st.button('Update')):

                if name:
                    update_name_by_id(new_movie,id)
                if date:
                    update_date_by_id(new_date,id)
                if director:
                    update_director_by_id(new_director,id)
                if cast:
                    update_cast_by_id(new_cast,id)
                if budget:
                    update_budget_by_id(new_budget,id)
                if duration:
                    update_duration_by_id(new_duration,id)
                if rating:
                    update_rating_by_id(new_rating,id)

        if(ch=='By Name'):
            name = st.text_input('Movie Name')

            c1, c2, c3 = st.columns(3)
            c4, c5, c6 = st.columns(3)
            c7, c8, c9 = st.columns(3)

            with c1:
                id = st.checkbox('Movie Id')
            with c2:
                date = st.checkbox('Date')
            with c3:
                director = st.checkbox('Director')
            with c4:
                cast = st.checkbox('Cast')
            with c5:
                budget = st.checkbox('Budget')
            with c6:
                duration = st.checkbox('Duration')
            with c7:
                rating = st.checkbox('Rating')


            if id:
                new_id = st.number_input("Movie Id")
            if date:
                new_date = st.date_input("Date")
            if director:
                new_director = st.text_input("Director")
            if cast:
                new_cast = st.text_input("Cast")
            if budget:
                new_budget = st.number_input("Budget")
            if duration:
                new_duration = st.number_input("Duration")
            if rating:
                new_rating = st.number_input("Rating")

            try:
                if (st.button('Update')):
                    if id:
                        update_id_by_name(new_id,name)
                    if date:
                        update_date_by_name(new_date,name)
                    if director:
                        update_director_by_name(new_director,name)
                    if cast:
                        update_cast_by_name(new_cast,name)
                    if budget:
                        update_budget_by_name(new_budget,name)
                    if duration:
                        update_duration_by_name(new_duration,name)
                    if rating:
                        update_rating_by_name(new_rating,name)
            except:
                st.write('Found an exception')
                st.write('Please enter valid data')

    if (choice == 'Search'):
    # if(choice3):
        ch = st.selectbox('Select',('By Id','By Name'))

        try:

            if (ch=='By Id'):
                search_by_id()

                if (st.button('Search')):
                    rec = curr.fetchone()
                    df = pd.DataFrame([rec],columns=['Id','Movie Name','Date','Director','Cast','Budget','Duration','Rating'])
                    st.dataframe(df)
                    conn.commit()

            if (ch=='By Name'):
                search_by_name()

                if (st.button('Search')):
                    rec = curr.fetchone()
                    df = pd.DataFrame([rec],columns=['Id','Movie Name','Date','Director','Cast','Budget','Duration','Rating'])
                    st.dataframe(df)
                    conn.commit()
        except Exception as ex:
            print('Found an exception :',ex)

    if (choice=='Display'):
    # if(choice5):
        display_query = "select * from movies"
        curr.execute(display_query)

        rec = curr.fetchall()
        df = pd.DataFrame(rec,columns=['Id','Movie Name','Date','Director','Cast','Budget','Duration','Rating'])
        st.dataframe(df)
        conn.commit()


except Exception as e:
    st.write("Something went wrong :",e)



